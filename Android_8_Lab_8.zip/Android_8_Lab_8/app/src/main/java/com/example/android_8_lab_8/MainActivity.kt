package com.example.android_8_lab_8

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import androidx.core.app.NotificationCompat
import androidx.core.app.TaskStackBuilder

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        // The id of the notification channel
        val mNotificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val id = "my_channel_02"

        // The user-visible name of the channel
        val name = getString(R.string.abc_action_bar_home_description)

        // the user-visible description of the channel
        val description = getString(R.string.abc_action_bar_home_description)
        val importance = NotificationManager.IMPORTANCE_HIGH

        val mChannel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel(id, name, importance)
        } else {
            TODO("VERSION.SDK_INT < O")
        }

        // Configure the notification channel
        mChannel.description = description
        mChannel.enableLights(true)

        /*
        Sets the notification light color for notification
        posted to this channel, if the devise supports this feature.
         */
        mChannel.lightColor = Color.RED
        mChannel.enableVibration(true)
        mNotificationManager.createNotificationChannel(mChannel)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val mywebview : WebView = findViewById(R.id.mywebview)
        mywebview.setWebViewClient(WebViewClient())

        when(item?.itemId){

            R.id.item1 -> {mywebview.loadUrl("https://www.androidatc.com")
                //----------------------------------------------------------
                // The id of the channel.
                val Channel_ID = "my_channel_02"

                //Using NotificationCompact.Builder to add the notification objects
                val mbuilder = NotificationCompat.Builder(this, Channel_ID)
                    .setSmallIcon(R.drawable.notification_icon_background)
                    .setContentTitle("Android ATC Notification")
                    .setContentText("Check Android ATC New Course !!")

                // creates an explicit intent for an activity in your app
                val resultIntent = Intent(this, ResultActivity::class.java)
                /*
                The stack builder object will contain an artificial back stack for
                the started Activity
                This ensures that navigation backwards from the activity leads out
                of your app to the home screen
                 */
                val stackBuilder = TaskStackBuilder.create(this)

                //Adds the Intent that starts the activity to the top of the stack
                stackBuilder.addNextIntent(resultIntent)
                val resultPendingIntent = stackBuilder.getPendingIntent(0,PendingIntent.FLAG_UPDATE_CURRENT)
                mbuilder.setContentIntent(resultPendingIntent)
                val mNotificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                /*
                   mNotificationID is a unique integer your app users to identify the
                   notification. For example, to cancel the notification, you can pass
                   its ID number to NoticfiactionManager.cancel
                 */
                   Log.d("now","end")
                mNotificationManager.notify(2,mbuilder.build())
                return super.onOptionsItemSelected(item)}

            R.id.item2 -> {mywebview.loadUrl("https://www.pearsonvue.com/androidatc")
                return super.onOptionsItemSelected(item)}

            else -> return super.onOptionsItemSelected(item)
        }

    }

    fun gotoweb(view: View) {

        // Configure your webView to enable Javascript, download images
        // and enable scrollbar"https://www.pearsonvue.com/androidatc"
        val mywebview: WebView = findViewById(R.id.mywebview)
        mywebview.settings.javaScriptEnabled = true
        mywebview.settings.loadsImagesAutomatically = true
        mywebview.scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY

        /*
        The URK of the web page sites will be taken from url_address
        TextView widget which will work as address bar
         */
        val url_address : EditText = findViewById(R.id.url_address)
        val url = url_address.text.toString()

        // To avoid webView to launch the default browser
        mywebview.setWebViewClient(WebViewClient())

        // Shows the URL
        mywebview.loadUrl(url)
    }
}