package com.example.android_8_lab_8

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.annotation.RequiresApi
import kotlin.math.max

class ResultActivity : AppCompatActivity() {
    //@RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

/*
        // The id of the notification channel
        val mNotificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val id = "my_channel_02"

        // The user-visible name of the channel
        val name = getString(R.string.abc_action_bar_home_description)

        // the user-visible description of the channel
        val description = getString(R.string.abc_action_bar_home_description)
        val importance = NotificationManager.IMPORTANCE_HIGH

        val mChannel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel(id, name, importance)
        } else {
            TODO("VERSION.SDK_INT < O")
        }

        // Configure the notification channel
        mChannel.description = description
        mChannel.enableLights(true)

        /*
        Sets the notification light color for notification
        posted to this channel, if the devise supports this feature.
         */
        mChannel.lightColor = Color.RED
        mChannel.enableVibration(true)
        mNotificationManager.createNotificationChannel(mChannel)*/
    }
}